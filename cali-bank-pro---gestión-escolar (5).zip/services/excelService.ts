
import * as XLSX from 'xlsx';
import { Student, Group } from '../types';

export const exportToExcel = (students: Student[], groups: Group[]) => {
  // 1. Hoja de Alumnos
  const studentData = students.map(s => ({
    ID: s.id,
    NOMBRE: s.name,
    GRUPO: groups.find(g => g.id === s.groupId)?.name || 'N/A',
    SALDO_CALIS: s.balance,
    DEUDA_ACTIVA: s.activeLoan?.isActive ? 'SÍ' : 'NO',
    MONTO_DEUDA: s.activeLoan?.amount || 0,
    ULTIMA_ASISTENCIA: s.lastAttendance ? new Date(s.lastAttendance).toLocaleString() : 'NUNCA'
  }));

  // 2. Hoja de Transacciones
  const allTransactions: any[] = [];
  students.forEach(s => {
    s.transactions.forEach(t => {
      allTransactions.push({
        ALUMNO: s.name,
        FECHA: new Date(t.timestamp).toLocaleString(),
        TIPO: t.type === 'CREDIT' ? 'INGRESO' : 'GASTO',
        CANTIDAD: t.amount,
        CONCEPTO: t.concept
      });
    });
  });

  const wb = XLSX.utils.book_new();
  
  const wsStudents = XLSX.utils.json_to_sheet(studentData);
  XLSX.utils.book_append_sheet(wb, wsStudents, "Alumnos");
  
  const wsTx = XLSX.utils.json_to_sheet(allTransactions);
  XLSX.utils.book_append_sheet(wb, wsTx, "Historial_Completo");

  // Generar archivo y descargar
  XLSX.writeFile(wb, `CaliBank_Reporte_${new Date().toLocaleDateString().replace(/\//g, '-')}.xlsx`);
};
