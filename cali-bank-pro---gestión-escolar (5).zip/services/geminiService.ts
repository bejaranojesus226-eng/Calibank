
import { GoogleGenAI, Type } from "@google/genai";
import { Student, Transaction } from "../types";

// Helper para obtener la API KEY de forma segura en el navegador
const getSafeApiKey = () => {
  try {
    // @ts-ignore
    return (typeof process !== 'undefined' && process.env && process.env.API_KEY) ? process.env.API_KEY : '';
  } catch {
    return '';
  }
};

export async function getStudentFeedback(student: Student): Promise<string> {
  const apiKey = getSafeApiKey();
  
  // Si no hay API KEY, devolvemos un mensaje genérico sin colapsar la app
  if (!apiKey) {
    return "¡Excelente trabajo! Sigue sumando Cali-Créditos para alcanzar tus metas de este periodo.";
  }

  const ai = new GoogleGenAI({ apiKey });

  const history = student.transactions.slice(-5).map(t => 
    `${t.type === 'CREDIT' ? 'Ganó' : 'Perdió'} ${t.amount} por ${t.concept}`
  ).join(', ');

  const prompt = `
    Como mentor financiero escolar, analiza el desempeño de:
    Nombre: ${student.name}
    Saldo: ${student.balance}Ȼ
    Reciente: ${history || 'Sin movimientos.'}
    Da un mensaje motivador de 1 párrafo sobre su ahorro y conducta.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "¡Cada Cali-Crédito cuenta!";
  } catch (error) {
    console.warn("IA Feedback Unavailable:", error);
    return "¡Vas por buen camino! Tu constancia en la clase se refleja en tu saldo.";
  }
}
