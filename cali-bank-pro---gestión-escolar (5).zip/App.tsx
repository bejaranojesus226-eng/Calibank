
import React, { useState, useEffect, useCallback } from 'react';
import { UserMode, Student, Transaction, Group, Reward } from './types';
import { TeacherDashboard } from './components/TeacherDashboard';
import { StudentDashboard } from './components/StudentDashboard';
import { 
  Wallet, GraduationCap, UserCircle, X, 
  TrendingUp, ShieldCheck, Cloud, CloudOff, Globe,
  RefreshCw, Save, Download
} from 'lucide-react';
import { playSuccessSound, playErrorSound, playCoinSound } from './services/audioService';
import { QRScanner } from './components/QRScanner';

// Clave para almacenamiento persistente
export const MASTER_STORAGE_KEY = 'calibank_cloud_v5';
const TEACHER_PASSWORD = "perroslocos93";
const TEACHER_QR_AUTH = "master_access_ricardo_2025";
const CLOUD_API_URL = 'https://api.npoint.io/bins';

const App: React.FC = () => {
  const [mode, setMode] = useState<UserMode>(UserMode.NONE);
  const [students, setStudents] = useState<Student[]>([]);
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [groups, setGroups] = useState<Group[]>([
    { id: 'default', name: 'GENERAL', createdAt: Date.now() },
  ]);
  const [selectedGroupId, setSelectedGroupId] = useState<string>('default');
  const [currentUnit, setCurrentUnit] = useState<number>(1);
  const [currentStudentId, setCurrentStudentId] = useState<string | null>(null);
  
  // Cloud ID persistente
  const [cloudId, setCloudId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(MASTER_STORAGE_KEY);
    } catch { return null; }
  });
  
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState(false);

  // Modales
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [showQRScanner, setShowQRScanner] = useState(false);
  const [joinIdInput, setJoinIdInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');

  // 1. WEB DATABASE: Función de carga desde la nube
  const fetchCloudData = useCallback(async (id: string) => {
    if (!id || id === 'null' || id.length < 5) return;
    setIsSyncing(true);
    setSyncError(false);
    try {
      const response = await fetch(`${CLOUD_API_URL}/${id}`, { cache: 'no-store' });
      if (!response.ok) throw new Error("Sync Error");
      const data = await response.json();
      const content = data.contents || data;
      if (content) {
        if (content.students) setStudents(content.students);
        if (content.groups) setGroups(content.groups);
        if (content.unit) setCurrentUnit(content.unit);
        if (content.rewards) setRewards(content.rewards);
        // Backup local inmediato
        localStorage.setItem(`backup_${id}`, JSON.stringify(content));
      }
    } catch (e) {
      console.error("Cloud fetch failed, using local backup", e);
      setSyncError(true);
      const backup = localStorage.getItem(`backup_${id}`);
      if (backup) {
        const content = JSON.parse(backup);
        setStudents(content.students || []);
        setGroups(content.groups || []);
      }
    } finally {
      setIsSyncing(false);
    }
  }, []);

  // 2. WEB DATABASE: Función de guardado automático
  const pushCloudData = async (newStudents: Student[], newGroups: Group[], unit: number, newRewards: Reward[]) => {
    // Guardar siempre en local primero por seguridad
    const payload = { students: newStudents, groups: newGroups, unit, rewards: newRewards };
    localStorage.setItem(`backup_${cloudId}`, JSON.stringify(payload));

    if (!cloudId || cloudId === 'null') return;
    
    setIsSyncing(true);
    try {
      const response = await fetch(`${CLOUD_API_URL}/${cloudId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error("Cloud push failed");
      setSyncError(false);
    } catch (e) {
      console.error("Auto-save failed, data kept locally", e);
      setSyncError(true);
    } finally {
      setIsSyncing(false);
    }
  };

  // Crear base de datos nueva
  const createNewCloudStore = async () => {
    setIsSyncing(true);
    try {
      const response = await fetch(CLOUD_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          students: [], 
          groups: [{ id: 'default', name: 'GENERAL', createdAt: Date.now() }], 
          unit: 1, 
          rewards: [] 
        })
      });
      const data = await response.json();
      if (data.id) {
        setCloudId(data.id);
        localStorage.setItem(MASTER_STORAGE_KEY, data.id);
        playSuccessSound();
        alert(`¡Base de Datos Online Activada!\nID: ${data.id}\nIMPORTANTE: Guarda este ID para entrar desde otros dispositivos.`);
      }
    } catch (e) {
      alert("Error de conexión. Intenta de nuevo.");
      playErrorSound();
    } finally {
      setIsSyncing(false);
    }
  };

  // 3. RESPALDO TXT: Función para descargar reporte individual por alumno
  const downloadStudentTxt = (student: Student) => {
    const history = student.transactions.map(t => 
      `[${new Date(t.timestamp).toLocaleString()}] ${t.type === 'CREDIT' ? '+' : '-'}${t.amount}Ȼ : ${t.concept}`
    ).join('\n');
    
    const content = `
========================================
       CALI-BANK - REPORTE ALUMNO
========================================
NOMBRE: ${student.name}
ID: ${student.id}
FECHA REPORTE: ${new Date().toLocaleString()}
----------------------------------------
SALDO ACTUAL: ${student.balance}Ȼ
ESTADO DE CRÉDITO: ${student.activeLoan?.isActive ? 'DEUDA PENDIENTE' : 'SIN DEUDAS'}
MONTO CRÉDITO: ${student.activeLoan?.amount || 0}Ȼ
----------------------------------------
HISTORIAL DE MOVIMIENTOS:
${history || 'Sin transacciones registradas.'}
========================================
    RICARDO ESPINO GONZALEZ © 2025
========================================
    `;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CaliBank_${student.name.replace(/\s/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Descarga de toda la base en un solo archivo TXT estructurado
  const downloadAllDataTxt = () => {
    let content = `BASE DE DATOS CALI-BANK - ${new Date().toLocaleString()}\n`;
    content += `CLOUD ID: ${cloudId}\n`;
    content += `--------------------------------------------------\n\n`;
    
    students.forEach(s => {
      content += `ALUMNO: ${s.name} | SALDO: ${s.balance}Ȼ | GRUPO: ${groups.find(g => g.id === s.groupId)?.name}\n`;
    });

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CaliBank_Full_Backup.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cid = params.get('cid');
    if (cid) {
      setCloudId(cid);
      localStorage.setItem(MASTER_STORAGE_KEY, cid);
      fetchCloudData(cid);
    } else if (cloudId) {
      fetchCloudData(cloudId);
    }
  }, [fetchCloudData, cloudId]);

  const updateBalance = (studentId: string, amount: number, concept: string, type: 'CREDIT' | 'DEBIT') => {
    const amountNum = Number(amount);
    const updated = students.map(s => {
      if (s.id === studentId) {
        const newTx: Transaction = { id: `tx_${Date.now()}`, type, amount: amountNum, concept: concept.toUpperCase(), timestamp: Date.now() };
        const newBalance = type === 'CREDIT' ? Number(s.balance) + amountNum : Math.max(0, Number(s.balance) - amountNum);
        return { ...s, balance: newBalance, transactions: [newTx, ...s.transactions] };
      }
      return s;
    });
    setStudents(updated);
    pushCloudData(updated, groups, currentUnit, rewards);
    if (type === 'CREDIT') playCoinSound(); else playErrorSound();
  };

  const addStudentsBatch = (names: string[], groupId: string) => {
    const newStudents: Student[] = names.map(name => ({
      id: `std_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: name.toUpperCase(),
      groupId: groupId,
      balance: 100,
      transactions: [{ id: `tx_init_${Date.now()}_${Math.random()}`, type: 'CREDIT', amount: 100, concept: 'BONO APERTURA', timestamp: Date.now() }],
      qrCode: '',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`,
    }));
    const updated = [...students, ...newStudents];
    setStudents(updated);
    pushCloudData(updated, groups, currentUnit, rewards);
    playSuccessSound();
  };

  const handleLoan = (studentId: string, amount: number) => {
    const updatedStudents = students.map(s => {
      if (s.id === studentId) {
        const tx: Transaction = { id: `tx_loan_${Date.now()}`, type: 'CREDIT', amount, concept: `CRÉDITO ASIGNADO`, timestamp: Date.now() };
        return { ...s, balance: s.balance + amount, activeLoan: { isActive: true, amount, timestamp: Date.now(), targetGoal: s.balance + amount + 500 }, transactions: [tx, ...s.transactions] };
      }
      return s;
    });
    setStudents(updatedStudents);
    pushCloudData(updatedStudents, groups, currentUnit, rewards);
    playSuccessSound();
  };

  if (mode === UserMode.NONE) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-white overflow-hidden relative">
        <div className="text-center mb-16 animate-zoom-in z-10">
          <div className="relative inline-block mb-10">
            <div className="absolute inset-0 bg-amber-500/20 rounded-full blur-3xl animate-pulse"></div>
            <div className="relative bg-slate-900/80 p-10 rounded-[4rem] border border-white/10 shadow-2xl">
              <Wallet size={80} className="text-amber-500 mx-auto" />
            </div>
          </div>
          <h1 className="text-8xl font-black mb-2 tracking-tighter italic bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-500">CALI-BANK</h1>
          <p className="text-amber-500 text-[10px] font-black uppercase tracking-[0.8em]">Sistema Digital de Monedero</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl z-10 px-4">
          <button onClick={() => setShowPasswordModal(true)} className="group bg-slate-900/40 border border-white/5 p-12 rounded-[4rem] hover:bg-indigo-600/10 transition-all shadow-2xl active:scale-95 text-left">
            <GraduationCap size={48} className="mb-6 text-indigo-400" />
            <h2 className="text-4xl font-black uppercase italic mb-2">Maestro</h2>
            <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest">Administrar Alumnos</p>
          </button>
          <button onClick={() => { setMode(UserMode.STUDENT); playSuccessSound(); }} className="group bg-slate-900/40 border border-white/5 p-12 rounded-[4rem] hover:bg-amber-600/10 transition-all shadow-2xl active:scale-95 text-left">
            <UserCircle size={48} className="mb-6 text-amber-500" />
            <h2 className="text-4xl font-black uppercase italic mb-2">Alumno</h2>
            <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest">Ver mi Billetera</p>
          </button>
        </div>

        <div className="mt-16 z-10">
           {!cloudId ? (
             <button onClick={createNewCloudStore} className="bg-indigo-600 text-white px-8 py-4 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-3 shadow-xl hover:bg-indigo-500 transition-all">
               <Globe size={16} /> Activar Base de Datos Online
             </button>
           ) : (
             <div className="flex flex-col items-center gap-4">
                <button onClick={() => setShowJoinModal(true)} className="text-slate-500 hover:text-white transition-colors text-[9px] font-black uppercase tracking-widest flex items-center gap-2">
                  <Cloud size={14} className={isSyncing ? "animate-spin" : ""} /> ID: {cloudId}
                </button>
             </div>
           )}
        </div>

        {/* Modal PIN */}
        {showPasswordModal && (
          <div className="fixed inset-0 z-[100] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
            <div className="bg-slate-900 border border-white/10 p-12 rounded-[4rem] w-full max-w-sm text-center relative shadow-2xl">
              <button onClick={() => setShowPasswordModal(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X size={28} /></button>
              <h3 className="text-xl font-black mb-8 uppercase italic">Pin Maestro</h3>
              <form onSubmit={(e) => { e.preventDefault(); if(passwordInput === TEACHER_PASSWORD) { setMode(UserMode.TEACHER); setShowPasswordModal(false); } else { alert("Error"); playErrorSound(); } }} className="space-y-6">
                <input autoFocus type="password" placeholder="PIN" value={passwordInput} onChange={(e) => setPasswordInput(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-3xl px-8 py-6 text-center font-bold text-xl outline-none" />
                <button type="submit" className="w-full bg-indigo-600 py-6 rounded-3xl font-black uppercase text-[10px] tracking-widest">Ingresar</button>
              </form>
            </div>
          </div>
        )}

        {/* Modal Sync */}
        {showJoinModal && (
          <div className="fixed inset-0 z-[100] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
            <div className="bg-slate-900 border border-white/10 p-12 rounded-[4rem] w-full max-w-sm text-center relative shadow-2xl">
              <button onClick={() => setShowJoinModal(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X size={28} /></button>
              <h3 className="text-xl font-black mb-8 uppercase italic">Vincular Base Existente</h3>
              <form onSubmit={(e) => { e.preventDefault(); if(joinIdInput){ setCloudId(joinIdInput); localStorage.setItem(MASTER_STORAGE_KEY, joinIdInput); fetchCloudData(joinIdInput); setShowJoinModal(false); } }} className="space-y-6">
                <input autoFocus type="text" placeholder="ID NPOINT" value={joinIdInput} onChange={(e) => setJoinIdInput(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-3xl px-8 py-6 text-center font-bold text-xl outline-none uppercase" />
                <button type="submit" className="w-full bg-indigo-600 py-6 rounded-3xl font-black uppercase text-[10px] tracking-widest">Sincronizar</button>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <nav className="border-b border-white/5 bg-slate-900/50 backdrop-blur-2xl sticky top-0 z-[60]">
        <div className="max-w-7xl mx-auto px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4 cursor-pointer" onClick={() => setMode(UserMode.NONE)}>
            <div className="bg-amber-500 p-2 rounded-xl"><Wallet size={20} className="text-slate-950" /></div>
            <span className="font-black text-2xl tracking-tighter uppercase italic">CALI-BANK</span>
          </div>
          <div className="flex items-center gap-6">
            <div className={`px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest border flex items-center gap-2 ${syncError ? "text-rose-500 border-rose-500/20" : "text-emerald-500 border-emerald-500/20"}`}>
               {isSyncing ? <RefreshCw size={10} className="animate-spin" /> : (syncError ? <CloudOff size={10} /> : <Cloud size={10} />)}
               {syncError ? "Error Red" : (isSyncing ? "Guardando..." : "Database Online")}
            </div>
            <button onClick={() => setMode(UserMode.NONE)} className="px-6 py-3 rounded-xl bg-white/5 text-[10px] font-black uppercase tracking-widest hover:bg-rose-600 transition-all">Salir</button>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto p-6 md:p-10 flex-1 w-full">
        {mode === UserMode.TEACHER ? (
          <TeacherDashboard 
            students={students} 
            groups={groups}
            rewards={rewards}
            createReward={(val) => {
              const id = `rw_${Date.now()}`;
              const newRewards = [...rewards, { id, amount: val, isUsed: false, createdAt: Date.now() }];
              setRewards(newRewards);
              pushCloudData(students, groups, currentUnit, newRewards);
              return id;
            }}
            selectedGroupId={selectedGroupId}
            setSelectedGroupId={setSelectedGroupId}
            addGroup={(name) => {
              const newGroups = [...groups, { id: `grp_${Date.now()}`, name: name.toUpperCase(), createdAt: Date.now() }];
              setGroups(newGroups);
              pushCloudData(students, newGroups, currentUnit, rewards);
            }}
            currentUnit={currentUnit}
            addStudent={(name) => addStudentsBatch([name], selectedGroupId)} 
            addStudentsBatch={addStudentsBatch}
            deleteStudent={(id) => {
               const updated = students.filter(s => s.id !== id);
               setStudents(updated);
               pushCloudData(updated, groups, currentUnit, rewards);
            }} 
            updateBalance={updateBalance} 
            handleLoan={handleLoan}
            generateSyncLink={() => {
              navigator.clipboard.writeText(`${window.location.origin}/?cid=${cloudId}`);
              alert("Enlace de sincronización copiado.");
            }}
            copyRawDb={downloadAllDataTxt}
            importRawDb={(text) => { return true; }}
          />
        ) : (
          <StudentDashboard 
            students={students} 
            currentUnit={currentUnit}
            currentStudentId={currentStudentId} 
            setCurrentStudentId={setCurrentStudentId} 
            registerAttendance={(id) => {
              const updated = students.map(s => {
                if (s.id === id) {
                  const tx: Transaction = { id: `tx_att_${Date.now()}`, type: 'CREDIT', amount: 1, concept: 'ASISTENCIA DIARIA', timestamp: Date.now() };
                  return { ...s, balance: s.balance + 1, lastAttendance: Date.now(), transactions: [tx, ...s.transactions] };
                }
                return s;
              });
              setStudents(updated);
              pushCloudData(updated, groups, currentUnit, rewards);
              playCoinSound();
            }} 
            requestLoan={handleLoan} 
            claimReward={(rwId, stdId) => {
               const rw = rewards.find(r => r.id === rwId);
               if(!rw || rw.isUsed) return;
               const updatedRw = rewards.map(r => r.id === rwId ? {...r, isUsed: true, usedBy: stdId} : r);
               const updatedStd = students.map(s => {
                 if(s.id === stdId) {
                   const tx: Transaction = { id: `tx_rw_${Date.now()}`, type: 'CREDIT', amount: rw.amount, concept: 'CANJE DE VALE', timestamp: Date.now() };
                   return { ...s, balance: s.balance + rw.amount, transactions: [tx, ...s.transactions] };
                 }
                 return s;
               });
               setRewards(updatedRw);
               setStudents(updatedStd);
               pushCloudData(updatedStd, groups, currentUnit, updatedRw);
               playSuccessSound();
            }}
          />
        )}
      </main>
      <footer className="p-8 text-center opacity-30 border-t border-white/5">
         <p className="text-[10px] font-black uppercase tracking-widest italic flex items-center justify-center gap-4">
           <span>RICARDO ESPINO GONZALEZ</span>
           <span className="w-1 h-1 bg-white rounded-full"></span>
           <span>Cali-Bank Pro v2.5</span>
         </p>
         <button onClick={downloadAllDataTxt} className="mt-4 text-[9px] font-black underline flex items-center justify-center gap-2 mx-auto">
           <Download size={10} /> Descargar Respaldo Estructural TXT
         </button>
      </footer>
    </div>
  );
};

export default App;
