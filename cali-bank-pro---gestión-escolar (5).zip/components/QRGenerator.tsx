
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

interface QRGeneratorProps {
  value: string;
  size?: number;
}

export const QRGenerator: React.FC<QRGeneratorProps> = ({ value, size = 160 }) => {
  return (
    <div className="bg-white p-4 rounded-2xl shadow-inner inline-block border-4 border-indigo-50">
      <QRCodeSVG 
        value={value} 
        size={size}
        level="H"
        includeMargin={false}
        className="rounded-lg"
      />
    </div>
  );
};
