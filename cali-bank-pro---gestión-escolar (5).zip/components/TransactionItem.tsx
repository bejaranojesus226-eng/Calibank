
import React from 'react';
import { Transaction } from '../types';
import { ArrowUpRight, ArrowDownLeft, Calendar } from 'lucide-react';

interface TransactionItemProps {
  transaction: Transaction;
}

export const TransactionItem: React.FC<TransactionItemProps> = ({ transaction }) => {
  const isCredit = transaction.type === 'CREDIT';
  
  return (
    <div className="flex items-center justify-between p-5 mb-2 rounded-3xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all group">
      <div className="flex items-center gap-5">
        <div className={`p-4 rounded-2xl ${isCredit ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'} group-hover:scale-110 transition-transform`}>
          {isCredit ? <ArrowUpRight size={24} /> : <ArrowDownLeft size={24} />}
        </div>
        <div className="overflow-hidden">
          <h4 className="font-black text-lg text-slate-100 truncate uppercase tracking-tight leading-none mb-1">{transaction.concept}</h4>
          <div className="flex items-center gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest">
            <Calendar size={12} />
            {new Date(transaction.timestamp).toLocaleDateString('es-MX', {
              day: 'numeric',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </div>
        </div>
      </div>
      <div className={`font-black text-2xl tracking-tighter ${isCredit ? 'text-emerald-400' : 'text-rose-400'}`}>
        {isCredit ? '+' : '-'}{transaction.amount}
      </div>
    </div>
  );
};
