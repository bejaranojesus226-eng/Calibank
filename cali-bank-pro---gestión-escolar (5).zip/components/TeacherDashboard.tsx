
import React, { useState } from 'react';
import { Student, TransactionType, Group, Reward } from '../types';
import { 
  UserPlus, Users, Trash2, X, QrCode, 
  FileSpreadsheet, Sparkles, Layers, ClipboardList, Landmark, AlertTriangle, Ghost, Download
} from 'lucide-react';
import { QRGenerator } from './QRGenerator';
import { playSuccessSound } from '../services/audioService';
import { exportToExcel } from '../services/excelService';

interface TeacherDashboardProps {
  students: Student[];
  groups: Group[];
  rewards: Reward[];
  createReward: (amount: number) => string;
  selectedGroupId: string;
  setSelectedGroupId: (id: string) => void;
  addGroup: (name: string) => void;
  currentUnit: number;
  addStudent: (name: string) => void;
  addStudentsBatch: (names: string[], groupId: string) => void;
  deleteStudent: (id: string) => void;
  updateBalance: (id: string, amount: number, concept: string, type: TransactionType) => void;
  handleLoan: (id: string, amount: number) => void;
  generateSyncLink: () => void;
  copyRawDb: () => void;
  importRawDb: (text: string) => boolean;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ 
  students, 
  groups,
  rewards,
  createReward,
  selectedGroupId,
  setSelectedGroupId,
  addGroup,
  addStudent, 
  addStudentsBatch,
  deleteStudent,
  updateBalance,
  handleLoan,
  copyRawDb
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showBatchImport, setShowBatchImport] = useState(false);
  const [showAddGroup, setShowAddGroup] = useState(false);
  const [showLoanPrompt, setShowLoanPrompt] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  const [batchInput, setBatchInput] = useState('');
  const [newStudentName, setNewStudentName] = useState('');
  const [newGroupName, setNewGroupName] = useState('');
  const [loanAmount, setLoanAmount] = useState('250');
  const [lastCreatedStudentId, setLastCreatedStudentId] = useState<string | null>(null);
  
  const [showRewardModal, setShowRewardModal] = useState(false);
  const [showStudentQR, setShowStudentQR] = useState(false);
  const [activeRewardId, setActiveRewardId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [customConcept, setCustomConcept] = useState('');
  const [customAmount, setCustomAmount] = useState<number>(0);

  const filteredStudents = students.filter(s => 
    s.groupId === selectedGroupId && 
    s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const selectedStudent = students.find(s => s.id === selectedStudentId);
  const currentGroup = groups.find(g => g.id === selectedGroupId);

  const downloadStudentTxt = (student: Student) => {
    const history = student.transactions.map(t => 
      `[${new Date(t.timestamp).toLocaleString()}] ${t.type === 'CREDIT' ? '+' : '-'}${t.amount}Ȼ : ${t.concept}`
    ).join('\n');
    
    const content = `
========================================
       CALI-BANK - REPORTE INDIVIDUAL
========================================
ALUMNO: ${student.name}
FECHA: ${new Date().toLocaleString()}
----------------------------------------
SALDO: ${student.balance}Ȼ
CRÉDITO: ${student.activeLoan?.isActive ? 'ACTIVO ('+student.activeLoan.amount+'Ȼ)' : 'LIMPIO'}
----------------------------------------
HISTORIAL:
${history || 'Sin movimientos.'}
========================================
    `;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Reporte_${student.name.replace(/\s/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleCreateStudent = () => {
    if (!newStudentName.trim()) return;
    addStudent(newStudentName.toUpperCase());
    setNewStudentName('');
    playSuccessSound();
  };

  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <div className="flex flex-col items-center gap-6">
        <div className="flex flex-wrap items-center justify-center gap-4 bg-slate-900/60 p-4 rounded-[3rem] border border-white/10 shadow-2xl">
            <button onClick={() => setShowAddGroup(true)} className="px-8 py-4 bg-indigo-600 text-white rounded-full font-black text-[10px] uppercase tracking-widest hover:bg-indigo-500 transition-all">
                NUEVA SECCIÓN
            </button>
            <button onClick={() => setShowBatchImport(true)} className="px-8 py-4 bg-white/5 border border-white/10 text-white rounded-full font-black text-[10px] uppercase tracking-widest hover:bg-white/10 transition-all">
                IMPORTAR LISTA
            </button>
            <div className="flex gap-2 overflow-x-auto max-w-[60vw] pb-1">
                {groups.map(group => (
                    <button 
                        key={group.id} 
                        onClick={() => { setSelectedGroupId(group.id); setSelectedStudentId(null); }}
                        className={`px-6 py-4 rounded-full font-black text-[9px] uppercase tracking-widest transition-all whitespace-nowrap border ${selectedGroupId === group.id ? 'bg-amber-500 text-slate-950 border-amber-400' : 'text-slate-500 border-transparent hover:text-white'}`}
                    >
                        {group.name}
                    </button>
                ))}
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900/60 border border-white/10 rounded-[4rem] p-10 h-[700px] flex flex-col backdrop-blur-3xl">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-black uppercase italic text-white">{currentGroup?.name}</h3>
              <button onClick={() => setShowAddForm(true)} className="p-4 bg-indigo-600 rounded-2xl"><UserPlus size={18} /></button>
            </div>
            
            <input type="text" placeholder="BUSCAR..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-black/40 border border-white/5 rounded-3xl px-6 py-5 text-[11px] text-white outline-none mb-6 uppercase font-black" />
            
            <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
              {filteredStudents.map(student => (
                <button 
                  key={student.id} 
                  onClick={() => setSelectedStudentId(student.id)} 
                  className={`w-full flex items-center justify-between p-5 rounded-[2rem] transition-all ${selectedStudentId === student.id ? 'bg-indigo-600 scale-105 shadow-xl' : 'bg-white/5 border border-white/5 hover:bg-white/10'}`}
                >
                  <div className="flex items-center gap-4 truncate">
                    <img src={student.avatar} className="w-10 h-10 rounded-xl bg-slate-800" alt="avatar" />
                    <span className="font-black text-[11px] uppercase truncate tracking-tight text-white">{student.name}</span>
                  </div>
                  <span className="font-black text-md text-amber-400">{student.balance}Ȼ</span>
                </button>
              ))}
            </div>
            
            <div className="mt-8 pt-6 border-t border-white/10 flex gap-4">
              <button onClick={() => setShowRewardModal(true)} className="flex-1 bg-amber-500 text-slate-950 py-4 rounded-[2rem] font-black text-[9px] uppercase tracking-widest shadow-xl">VALE QR</button>
              <button onClick={() => exportToExcel(students, groups)} className="flex-1 bg-emerald-600 text-white py-4 rounded-[2rem] font-black text-[9px] uppercase tracking-widest shadow-xl">EXCEL</button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8">
          {selectedStudent ? (
            <div className="bg-slate-900/40 backdrop-blur-3xl border border-white/10 rounded-[5rem] p-16 min-h-[700px] relative">
              <div className="flex flex-col md:flex-row items-center gap-10 mb-16">
                <div className="relative group cursor-pointer" onClick={() => setShowStudentQR(true)}>
                  <img src={selectedStudent.avatar} className="w-56 h-56 rounded-[4rem] bg-slate-950 border-4 border-white/10 shadow-2xl" alt="avatar" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/60 rounded-[4rem] transition-all">
                    <QrCode size={48} className="text-white" />
                  </div>
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-6xl font-black uppercase tracking-tighter mb-8 italic text-white drop-shadow-2xl">{selectedStudent.name}</h2>
                  <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                    <div className="bg-white text-slate-950 px-10 py-6 rounded-[3rem] flex items-center gap-6 shadow-2xl">
                      <span className="text-5xl font-black">{selectedStudent.balance}</span>
                      <span className="text-2xl font-black">Ȼ</span>
                    </div>
                    <button onClick={() => setShowLoanPrompt(true)} className="px-8 bg-amber-500 text-slate-950 rounded-[3rem] font-black text-[10px] uppercase tracking-widest hover:bg-amber-400">CRÉDITO</button>
                    <button onClick={() => downloadStudentTxt(selectedStudent)} className="p-6 bg-indigo-600 text-white rounded-[3rem] hover:bg-indigo-500 shadow-xl" title="Descargar Historial TXT">
                      <Download size={24} />
                    </button>
                    <button onClick={() => setShowDeleteConfirm(true)} className="p-6 bg-rose-600/10 text-rose-500 hover:bg-rose-600 hover:text-white rounded-[3rem] transition-all">
                        <Trash2 size={24} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white/5 p-8 rounded-[4rem] border border-white/5">
                  <h4 className="text-[9px] font-black uppercase tracking-widest text-indigo-400 mb-6">Acciones Rápidas</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => updateBalance(selectedStudent.id, 10, 'Participación', 'CREDIT')} className="bg-emerald-500 text-slate-950 p-4 rounded-3xl font-black text-[9px] uppercase">Participar (+10)</button>
                    <button onClick={() => updateBalance(selectedStudent.id, 20, 'Liderazgo', 'CREDIT')} className="bg-indigo-600 text-white p-4 rounded-3xl font-black text-[9px] uppercase">Líder (+20)</button>
                    <button onClick={() => updateBalance(selectedStudent.id, 5, 'Orden', 'CREDIT')} className="bg-amber-500 text-slate-950 p-4 rounded-3xl font-black text-[9px] uppercase">Orden (+5)</button>
                    <button onClick={() => updateBalance(selectedStudent.id, 15, 'Equipo', 'CREDIT')} className="bg-slate-800 text-white p-4 rounded-3xl font-black text-[9px] uppercase">Equipo (+15)</button>
                  </div>
                </div>
                <div className="bg-white/5 p-8 rounded-[4rem] border border-white/5">
                  <h4 className="text-[9px] font-black uppercase tracking-widest text-rose-500 mb-6">Ajuste Manual</h4>
                  <div className="space-y-3">
                    <input type="text" placeholder="CONCEPTO..." value={customConcept} onChange={e => setCustomConcept(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 text-[10px] text-white uppercase font-black" />
                    <div className="flex gap-3">
                      <input type="number" value={customAmount || ''} onChange={e => setCustomAmount(Number(e.target.value))} className="w-20 bg-black/40 border border-white/10 rounded-2xl text-center text-xl font-black text-amber-500" />
                      <button onClick={() => { updateBalance(selectedStudent.id, customAmount, customConcept || 'AJUSTE', 'CREDIT'); setCustomAmount(0); }} className="flex-1 bg-emerald-500 text-slate-950 rounded-2xl font-black text-[9px] uppercase">Abono</button>
                      <button onClick={() => { updateBalance(selectedStudent.id, customAmount, customConcept || 'AJUSTE', 'DEBIT'); setCustomAmount(0); }} className="flex-1 bg-rose-600 text-white rounded-2xl font-black text-[9px] uppercase">Multa</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center border-4 border-dashed border-white/5 rounded-[5rem] text-slate-700 opacity-30 italic p-20 text-center">
              <Sparkles size={80} className="mb-6" />
              <p className="text-lg font-black uppercase tracking-widest">Selecciona un alumno para administrar sus Calis</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal Agregar Grupo */}
      {showAddGroup && (
        <div className="fixed inset-0 z-[200] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-white/10 p-12 rounded-[4rem] w-full max-w-sm text-center shadow-2xl relative">
            <button onClick={() => setShowAddGroup(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X size={28} /></button>
            <h3 className="text-2xl font-black mb-8 uppercase italic">Nuevo Grupo</h3>
            <input autoFocus type="text" placeholder="EJ: 3ºB..." value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-3xl px-8 py-6 text-center font-black text-xl outline-none uppercase mb-6" />
            <button onClick={() => { addGroup(newGroupName); setNewGroupName(''); setShowAddGroup(false); }} className="w-full bg-indigo-600 py-6 rounded-3xl font-black uppercase text-[10px] tracking-widest">Crear</button>
          </div>
        </div>
      )}

      {/* Modal Agregar Alumno */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-950/98 z-[200] flex items-center justify-center p-6 animate-in fade-in">
          <div className="bg-slate-900 border border-white/10 p-16 rounded-[4rem] max-w-xl w-full text-center relative">
             <button onClick={() => setShowAddForm(false)} className="absolute top-10 right-10 text-slate-500 hover:text-white"><X size={32} /></button>
             {!lastCreatedStudentId ? (
                <div>
                    <h3 className="text-3xl font-black mb-10 uppercase italic">Nuevo Alumno</h3>
                    <input autoFocus type="text" placeholder="NOMBRE COMPLETO..." value={newStudentName} onChange={e => setNewStudentName(e.target.value)} onKeyDown={e => { if(e.key === 'Enter') handleCreateStudent(); }} className="w-full bg-black/40 border border-white/10 rounded-[2rem] px-8 py-8 text-white uppercase font-black outline-none text-center text-2xl mb-10 italic" />
                    <button onClick={handleCreateStudent} className="w-full bg-indigo-600 py-8 rounded-[2.5rem] font-black uppercase text-[12px] tracking-widest shadow-2xl">Registrar</button>
                </div>
             ) : (
                <div className="animate-in zoom-in">
                    <h3 className="text-3xl font-black mb-10 uppercase italic">¡Listo!</h3>
                    <div className="bg-white p-10 rounded-[4rem] inline-block mb-10 shadow-2xl"><QRGenerator value={lastCreatedStudentId} size={250} /></div>
                    <button onClick={() => { setLastCreatedStudentId(null); setNewStudentName(''); }} className="w-full bg-indigo-600 py-6 rounded-[2rem] font-black uppercase text-[11px]">Otro Registro</button>
                </div>
             )}
          </div>
        </div>
      )}

      {/* Modal Importar Lote */}
      {showBatchImport && (
        <div className="fixed inset-0 bg-slate-950/98 z-[200] flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-white/10 p-12 rounded-[4rem] max-w-xl w-full text-center relative shadow-2xl">
             <button onClick={() => setShowBatchImport(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X size={28} /></button>
             <h3 className="text-2xl font-black mb-6 uppercase italic text-white">Importar Lista</h3>
             <p className="text-slate-500 text-[9px] mb-6 font-black uppercase tracking-widest italic">Pega nombres (uno por línea)</p>
             <textarea placeholder="PABLO GARCIA&#10;MARIA LOPEZ..." value={batchInput} onChange={e => setBatchInput(e.target.value)} className="w-full h-64 bg-black/40 border border-white/10 rounded-[2rem] p-8 text-white uppercase font-black mb-8 outline-none text-md"></textarea>
             <button onClick={() => { const names = batchInput.split('\n').filter(n => n.trim()); addStudentsBatch(names, selectedGroupId); setShowBatchImport(false); setBatchInput(''); }} className="w-full bg-indigo-600 py-6 rounded-3xl font-black uppercase text-[11px] tracking-widest shadow-2xl">Importar Ahora</button>
          </div>
        </div>
      )}

      {/* Modal Préstamo */}
      {showLoanPrompt && (
        <div className="fixed inset-0 z-[200] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-white/10 p-12 rounded-[4rem] w-full max-w-sm text-center shadow-2xl relative">
            <button onClick={() => setShowLoanPrompt(false)} className="absolute top-8 right-8 text-slate-500 hover:text-white"><X size={28} /></button>
            <Landmark size={48} className="text-amber-500 mx-auto mb-6" />
            <h3 className="text-2xl font-black mb-8 uppercase italic">Cali-Crédito</h3>
            <input autoFocus type="number" value={loanAmount} onChange={(e) => setLoanAmount(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-3xl px-8 py-8 text-center font-black text-5xl outline-none text-amber-500 mb-8" />
            <button onClick={() => { handleLoan(selectedStudent!.id, Number(loanAmount)); setShowLoanPrompt(false); }} className="w-full bg-amber-500 text-slate-950 font-black py-6 rounded-3xl text-[11px] uppercase tracking-widest shadow-2xl">Aprobar</button>
          </div>
        </div>
      )}

      {/* Modal Borrar */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[200] bg-slate-950/98 backdrop-blur-3xl flex items-center justify-center p-6">
          <div className="bg-slate-900 border border-white/10 p-12 rounded-[4rem] w-full max-w-sm text-center shadow-2xl relative">
            <AlertTriangle size={48} className="text-rose-500 mx-auto mb-6" />
            <h3 className="text-2xl font-black mb-4">¿Borrar Alumno?</h3>
            <p className="text-slate-500 font-bold mb-10 text-[10px] uppercase">Esta acción no se puede deshacer.</p>
            <div className="flex gap-4">
              <button onClick={() => { deleteStudent(selectedStudent!.id); setSelectedStudentId(null); setShowDeleteConfirm(false); }} className="flex-1 bg-rose-600 py-5 rounded-3xl font-black text-[10px] uppercase">Eliminar</button>
              <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 bg-white/5 py-5 rounded-3xl font-black text-[10px] uppercase">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Vale QR */}
      {showRewardModal && (
        <div className="fixed inset-0 bg-slate-950/98 z-[200] flex items-center justify-center p-6 animate-in zoom-in">
          <div className="bg-slate-900 border border-white/10 p-16 rounded-[4rem] max-w-xl w-full text-center relative shadow-2xl">
            <button onClick={() => { setShowRewardModal(false); setActiveRewardId(null); }} className="absolute top-10 right-10 text-slate-500 hover:text-white"><X size={32} /></button>
            {!activeRewardId ? (
              <div className="grid grid-cols-3 gap-4 mb-8">
                {[10, 50, 100].map(val => (
                  <button key={val} onClick={() => setActiveRewardId(createReward(val))} className="bg-white/5 border border-white/10 hover:bg-amber-500 hover:text-slate-950 p-8 rounded-[3rem] transition-all">
                    <span className="block text-4xl font-black mb-2">{val}</span>
                    <span className="text-[9px] font-black uppercase">Calis</span>
                  </button>
                ))}
              </div>
            ) : (
              <div className="animate-in fade-in zoom-in text-center">
                <div className="bg-white p-8 rounded-[4rem] inline-block mb-10 shadow-2xl">
                  <QRGenerator value={`reward_${activeRewardId}`} size={280} />
                </div>
                <button onClick={() => setActiveRewardId(null)} className="w-full bg-white/5 text-slate-500 font-black py-6 rounded-3xl text-[10px] uppercase">Nuevo Vale</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* QR Zoom */}
      {showStudentQR && selectedStudent && (
        <div className="fixed inset-0 bg-slate-950/98 backdrop-blur-3xl z-[200] flex items-center justify-center p-6 animate-in zoom-in" onClick={() => setShowStudentQR(false)}>
          <div className="bg-slate-900 border border-white/10 p-20 rounded-[5rem] max-w-sm w-full text-center shadow-2xl relative" onClick={e => e.stopPropagation()}>
            <div className="bg-white p-10 rounded-[4rem] inline-block mb-10 shadow-2xl"><QRGenerator value={selectedStudent.id} size={280} /></div>
            <h3 className="text-white font-black text-3xl mb-8 uppercase italic leading-none">{selectedStudent.name}</h3>
            <button onClick={() => setShowStudentQR(false)} className="w-full bg-indigo-600 py-6 rounded-3xl font-black uppercase text-[10px] tracking-widest shadow-2xl">Cerrar</button>
          </div>
        </div>
      )}
    </div>
  );
};
