
import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, CameraOff, Loader2, ShieldAlert, RefreshCw } from 'lucide-react';

interface QRScannerProps {
  onScan: (id: string) => void;
  onClose: () => void;
}

export const QRScanner: React.FC<QRScannerProps> = ({ onScan, onClose }) => {
  const [error, setError] = useState<{ message: string; type: 'permission' | 'generic' | null }>({ message: '', type: null });
  const [isInitializing, setIsInitializing] = useState(true);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerId = "qr-reader";

  const stopScanner = async () => {
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.stop();
      } catch (e) {
        console.warn("Error stopping scanner:", e);
      }
    }
  };

  const startScanner = async () => {
    try {
      setIsInitializing(true);
      setError({ message: '', type: null });
      
      // Limpiar instancia previa si existe
      await stopScanner();
      
      // Pequeña pausa para asegurar que el DOM esté listo y no haya conflictos de hardware
      await new Promise(resolve => setTimeout(resolve, 500));

      const html5QrCode = new Html5Qrcode(containerId);
      scannerRef.current = html5QrCode;

      const config = {
        fps: 15,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0
      };

      await html5QrCode.start(
        { facingMode: "environment" },
        config,
        (decodedText) => {
          let studentId = decodedText;
          if (decodedText.includes('sid=')) {
            try {
              const url = new URL(decodedText);
              studentId = url.searchParams.get('sid') || decodedText;
            } catch (e) {
              if (decodedText.includes('?')) {
                const parts = decodedText.split('sid=');
                if (parts.length > 1) {
                  studentId = parts[1].split('&')[0];
                }
              }
            }
          }
          
          html5QrCode.stop().then(() => {
            onScan(studentId);
          }).catch(err => {
            console.error("Error stopping scanner after success", err);
            onScan(studentId);
          });
        },
        () => {
          // Ignorar errores de frame individual
        }
      );
      setIsInitializing(false);
    } catch (err: any) {
      console.error("Error starting QR scanner:", err);
      setIsInitializing(false);
      
      const errorStr = err.toString().toLowerCase();
      const isPermissionError = 
        err.name === 'NotAllowedError' || 
        errorStr.includes('permission denied') || 
        errorStr.includes('permission dismissed') ||
        errorStr.includes('notallowederror');

      if (isPermissionError) {
        setError({
          message: "Acceso denegado o cancelado. Para usar el escáner, debes permitir el acceso a la cámara en este sitio.",
          type: 'permission'
        });
      } else if (err.name === 'NotFoundError' || errorStr.includes('notfounderror')) {
        setError({
          message: "No se detectó ninguna cámara disponible en este dispositivo.",
          type: 'generic'
        });
      } else {
        setError({
          message: "Hubo un problema al conectar con la cámara. Asegúrate de que no esté siendo usada por otra aplicación.",
          type: 'generic'
        });
      }
    }
  };

  useEffect(() => {
    // Iniciamos con un pequeño retraso para permitir que el modal termine de animarse
    const timer = setTimeout(startScanner, 500);

    return () => {
      clearTimeout(timer);
      stopScanner();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-center p-6">
      <div className="bg-slate-900 border border-white/10 p-6 md:p-10 rounded-[3rem] w-full max-w-xl shadow-2xl relative overflow-hidden flex flex-col items-center">
        
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-2 bg-white/5 hover:bg-white/10 rounded-full transition-colors text-slate-400 z-50"
        >
          <X size={24} />
        </button>

        <div className="text-center mb-8">
          <h3 className="text-3xl font-black tracking-tighter text-white mb-2">ESCÁNER QR</h3>
          <p className="text-slate-400 text-sm font-medium">Usa tu cámara para identificarte rápidamente</p>
        </div>

        <div className="relative w-full aspect-square max-w-[350px] bg-black rounded-[2rem] overflow-hidden border-4 border-white/5 shadow-inner">
          {isInitializing && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 z-10">
              <Loader2 size={40} className="text-indigo-500 animate-spin mb-4" />
              <p className="text-xs font-black uppercase tracking-widest text-slate-500">Activando cámara...</p>
            </div>
          )}

          {error.type && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 z-20 p-8 text-center animate-zoom-in">
              {error.type === 'permission' ? (
                <ShieldAlert size={56} className="text-amber-500 mb-6" />
              ) : (
                <CameraOff size={56} className="text-rose-500 mb-6" />
              )}
              
              <h4 className="text-white font-black text-xl mb-4 uppercase tracking-tighter">
                {error.type === 'permission' ? 'Cámara Bloqueada' : 'Error de Cámara'}
              </h4>
              
              <p className="text-slate-400 font-medium text-sm mb-8 leading-relaxed">
                {error.message}
              </p>

              <div className="flex flex-col gap-3 w-full">
                <button 
                  onClick={startScanner}
                  className="flex items-center justify-center gap-2 w-full px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-500 transition-all shadow-lg active:scale-95"
                >
                  <RefreshCw size={18} /> Reintentar Acceso
                </button>
                <button 
                  onClick={onClose}
                  className="w-full px-6 py-4 bg-white/5 text-slate-400 rounded-2xl font-bold hover:bg-white/10 transition-all"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )}

          <div id={containerId} className="w-full h-full"></div>
          
          {!error.type && !isInitializing && (
            <div className="absolute inset-0 pointer-events-none border-[40px] border-slate-900/40">
              <div className="w-full h-full border-2 border-indigo-500/50 rounded-xl relative">
                 <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-indigo-400 -mt-1 -ml-1"></div>
                 <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-indigo-400 -mt-1 -mr-1"></div>
                 <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-indigo-400 -mb-1 -ml-1"></div>
                 <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-indigo-400 -mb-1 -mr-1"></div>
                 <div className="absolute top-1/2 left-0 w-full h-0.5 bg-indigo-500/30 animate-pulse"></div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-8 flex items-center gap-4 bg-white/5 px-6 py-3 rounded-2xl border border-white/5">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">
            Buscando código QR en tiempo real
          </p>
        </div>
      </div>
    </div>
  );
};
