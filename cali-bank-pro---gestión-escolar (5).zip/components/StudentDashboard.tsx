
import React, { useState, useEffect } from 'react';
import { Student } from '../types';
import { QRGenerator } from './QRGenerator';
import { TransactionItem } from './TransactionItem';
import { Sparkles, ArrowLeft, UserCircle, ScanLine, CalendarCheck, CheckCircle2, Landmark, X, RefreshCw, Award, Coins } from 'lucide-react';
import { getStudentFeedback } from '../services/geminiService';
import { playSuccessSound, playErrorSound } from '../services/audioService';
import { QRScanner } from './QRScanner';

interface StudentDashboardProps {
  students: Student[];
  currentUnit: number;
  currentStudentId: string | null;
  setCurrentStudentId: (id: string | null) => void;
  registerAttendance: (studentId: string) => void;
  requestLoan: (studentId: string, amount: number) => void;
  claimReward: (rewardId: string, studentId: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ 
  students, 
  currentUnit,
  currentStudentId, 
  setCurrentStudentId,
  registerAttendance,
  requestLoan,
  claimReward
}) => {
  const [inputId, setInputId] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [loadingFeedback, setLoadingFeedback] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [loanAmount, setLoanAmount] = useState<number>(250);

  const currentStudent = students.find(s => s.id === currentStudentId);

  const handleScanResult = (decoded: string) => {
    if (decoded.startsWith('reward_')) {
      const rewardId = decoded.replace('reward_', '');
      if (currentStudent) {
        claimReward(rewardId, currentStudent.id);
        setShowScanner(false);
      }
    } else {
      const found = students.find(s => s.id === decoded || s.name.toLowerCase() === decoded.toLowerCase());
      if (found) {
        setCurrentStudentId(found.id);
        setShowScanner(false);
        playSuccessSound();
      } else {
        alert("Credencial no reconocida.");
        playErrorSound();
      }
    }
  };

  const isAttendanceRegisteredToday = () => {
    if (!currentStudent?.lastAttendance) return false;
    const now = new Date();
    const last = new Date(currentStudent.lastAttendance);
    return now.toDateString() === last.toDateString();
  };

  const handleRequestLoan = () => {
    if (currentStudent) {
      if (loanAmount < 10 || loanAmount > 500) {
        alert("Ajusta el monto entre 10 y 500.");
        playErrorSound();
        return;
      }
      
      const targetGoal = currentStudent.balance < 1000 ? 1000 : 2000;
      const penalty = loanAmount * 2;

      if (confirm(`¿Aceptar Cali-Crédito de ${loanAmount}Ȼ?\n\nMeta de condonación: ${targetGoal}Ȼ.\nSi fallas, la multa será de ${penalty}Ȼ.`)) {
        requestLoan(currentStudent.id, loanAmount);
        setShowLoanModal(false);
      }
    }
  };

  useEffect(() => {
    if (currentStudent && !feedback) {
       setLoadingFeedback(true);
       getStudentFeedback(currentStudent).then(setFeedback).finally(() => setLoadingFeedback(false));
    }
  }, [currentStudent]);

  if (!currentStudent) {
    return (
      <div className="max-w-md mx-auto mt-12 animate-in fade-in duration-500">
        {showScanner && <QRScanner onScan={handleScanResult} onClose={() => setShowScanner(false)} />}
        <div className="bg-slate-900/40 backdrop-blur-3xl p-12 rounded-[5rem] shadow-2xl border border-white/5 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-amber-500 via-indigo-500 to-amber-500 animate-pulse"></div>
          <div className="w-24 h-24 bg-indigo-500/10 text-indigo-400 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 border border-indigo-500/20 shadow-inner"><UserCircle size={56} /></div>
          <h2 className="text-4xl font-black mb-10 uppercase tracking-tighter italic">Cali-Billetera</h2>
          <button onClick={() => setShowScanner(true)} className="w-full bg-indigo-600 text-white font-black py-7 rounded-[2rem] flex items-center justify-center gap-4 text-[12px] uppercase tracking-[0.3em] mb-6 shadow-2xl active:scale-95 transition-all"><ScanLine size={24} /> ESCANEAR PASE</button>
          <form onSubmit={(e) => { e.preventDefault(); handleScanResult(inputId); }} className="space-y-4">
            <input type="text" placeholder="MI NOMBRE..." value={inputId} onChange={e => setInputId(e.target.value)} className="w-full bg-slate-950/50 border border-white/5 rounded-[2rem] px-8 py-6 text-white text-lg text-center font-black outline-none focus:border-amber-500 uppercase placeholder:text-slate-800" />
            <button type="submit" className="w-full bg-white/5 text-white font-black py-6 rounded-[2rem] text-[10px] uppercase tracking-widest border border-white/5">Acceso Manual</button>
          </form>
        </div>
      </div>
    );
  }

  const registeredToday = isAttendanceRegisteredToday();
  const hasLoan = currentStudent.activeLoan?.isActive;

  return (
    <div className="max-w-6xl mx-auto pb-16 animate-in fade-in duration-700">
      {showScanner && <QRScanner onScan={handleScanResult} onClose={() => setShowScanner(false)} />}
      
      <div className="flex flex-col lg:flex-row justify-between items-center gap-8 mb-12">
        <button onClick={() => { setCurrentStudentId(null); setFeedback(null); }} className="text-slate-500 hover:text-white font-black uppercase text-[11px] tracking-[0.3em] flex items-center gap-3 transition-colors"><ArrowLeft size={20} /> Salir del Sistema</button>
        <div className="flex flex-wrap justify-center gap-4 w-full lg:w-auto">
          <button onClick={() => setShowLoanModal(true)} className={`flex-1 lg:flex-none flex items-center justify-center gap-4 px-10 py-5 border rounded-[2.2rem] font-black text-[11px] uppercase tracking-widest transition-all ${hasLoan ? 'bg-amber-500/20 text-amber-500 border-amber-500/40 shadow-[0_0_40px_rgba(245,158,11,0.2)]' : 'bg-white/5 text-indigo-400 border-indigo-400/20 hover:bg-white/10'}`}>
            <Landmark size={18} /> {hasLoan ? 'Crédito Activo' : 'Solicitar Crédito'}
          </button>
          <button onClick={() => registerAttendance(currentStudent.id)} disabled={registeredToday} className={`flex-1 lg:flex-none flex items-center justify-center gap-4 px-10 py-5 rounded-[2.2rem] font-black text-[11px] uppercase tracking-widest transition-all ${registeredToday ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 shadow-xl shadow-emerald-500/20 active:scale-95'}`}>
            {registeredToday ? <CheckCircle2 size={18} /> : <CalendarCheck size={18} />}
            {registeredToday ? 'ASISTENCIA REGISTRADA' : 'REGISTRAR ASISTENCIA (+1Ȼ)'}
          </button>
          <button onClick={() => setShowScanner(true)} className="bg-amber-500 text-slate-950 px-10 py-5 rounded-[2.2rem] font-black text-[11px] uppercase tracking-widest flex items-center gap-4 shadow-xl active:scale-95 transition-all">
            <Award size={20} /> CANJEAR RECOMPENSA
          </button>
        </div>
      </div>

      <div className={`rounded-[5.5rem] p-16 text-white shadow-2xl relative overflow-hidden mb-16 border transition-all duration-1000 ${hasLoan ? 'bg-slate-950 border-amber-500/40 shadow-[0_0_80px_rgba(245,158,11,0.1)]' : 'bg-gradient-to-br from-indigo-700 via-indigo-900 to-slate-950 border-white/10'}`}>
        <div className="absolute top-0 right-0 p-16 opacity-5 pointer-events-none"><Coins size={350} /></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-16">
          <div className="text-center md:text-left">
            <p className="text-indigo-200 text-[12px] font-black uppercase tracking-[0.8em] mb-10 opacity-60 italic">Billetera Cali-Digital</p>
            <div className="flex items-baseline gap-6 justify-center md:justify-start">
              <h1 className="text-[11rem] md:text-[13rem] font-black tracking-tighter leading-[0.8] balance-text">{currentStudent.balance}</h1>
              <span className={`text-7xl font-black ${hasLoan ? 'text-amber-500' : 'text-indigo-400'}`}>Ȼ</span>
            </div>
            {hasLoan && (
              <div className="mt-12 inline-block bg-amber-500/10 border border-amber-500/20 px-10 py-4 rounded-full text-amber-500 font-black text-[11px] uppercase tracking-[0.2em] shadow-xl">
                CAPITAL PRESTADO: {currentStudent.activeLoan?.amount}Ȼ
              </div>
            )}
            <div className="mt-16 flex items-center gap-8 bg-black/40 backdrop-blur-3xl p-8 rounded-[3.5rem] border border-white/10 shadow-inner">
               <img src={currentStudent.avatar} className="w-24 h-24 rounded-[2.5rem] bg-indigo-500/20 shadow-2xl border border-white/10" alt="avatar" />
               <div className="flex flex-col">
                 <p className="text-4xl font-black uppercase tracking-tighter italic text-white">{currentStudent.name}</p>
                 <p className="text-[11px] font-black text-slate-500 uppercase tracking-widest mt-1">Líder Cali-Bank Certificado</p>
               </div>
            </div>
          </div>
          <div className="bg-white p-10 rounded-[5rem] shadow-2xl cursor-pointer hover:rotate-3 transition-transform group" onClick={() => setShowQRModal(true)}>
             <QRGenerator value={currentStudent.id} size={220} />
             <p className="text-[10px] text-slate-400 font-black uppercase mt-8 text-center tracking-[0.6em] group-hover:text-indigo-500 transition-colors">Ver Identificador</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="bg-slate-900/40 backdrop-blur-3xl border border-white/5 rounded-[5rem] p-14 shadow-2xl group">
           <div className="flex items-center gap-6 mb-12"><Sparkles size={28} className="text-indigo-400 group-hover:rotate-180 transition-transform duration-1000" /><h3 className="text-[11px] font-black uppercase tracking-[0.5em] text-slate-500">Retroalimentación IA</h3></div>
           {loadingFeedback ? (
             <div className="flex flex-col items-center py-16">
               <RefreshCw size={48} className="animate-spin text-indigo-400 mb-8" />
               <p className="text-[12px] font-black uppercase tracking-widest text-slate-700">Calculando proyecciones...</p>
             </div>
           ) : (
             <p className="text-slate-100 italic text-2xl leading-relaxed font-semibold">"{feedback}"</p>
           )}
        </div>
        <div className="bg-slate-900/40 backdrop-blur-3xl border border-white/5 rounded-[5rem] p-14 shadow-2xl">
          <h3 className="text-[11px] font-black mb-12 uppercase tracking-[0.5em] text-slate-500">Historial Financiero</h3>
          <div className="space-y-4 max-h-[450px] overflow-y-auto custom-scrollbar pr-6">
            {currentStudent.transactions.length > 0 ? (
              currentStudent.transactions.map(tx => <TransactionItem key={tx.id} transaction={tx} />)
            ) : (
              <div className="h-64 flex flex-col items-center justify-center opacity-10">
                <Coins size={80} className="mb-6" />
                <p className="font-black uppercase text-[12px] tracking-[0.5em]">Sin Movimientos</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {showLoanModal && (
        <div className="fixed inset-0 bg-slate-950/98 backdrop-blur-3xl z-[100] flex items-center justify-center p-6 animate-in fade-in">
          <div className="bg-slate-900 border border-white/10 p-16 rounded-[6rem] max-w-xl w-full shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-3 bg-amber-500"></div>
            <button onClick={() => setShowLoanModal(false)} className="absolute top-14 right-14 text-slate-500 hover:text-white transition-colors"><X size={40} /></button>
            <div className="text-center">
              <div className="w-24 h-24 bg-amber-500/10 text-amber-500 rounded-[3rem] flex items-center justify-center mx-auto mb-10 shadow-inner"><Landmark size={48} /></div>
              <h2 className="text-5xl font-black mb-4 uppercase italic tracking-tighter text-white">Cali-Crédito</h2>
              <p className="text-slate-500 text-[12px] font-black uppercase tracking-[0.4em] mb-16 italic">Sistema de Inversión Educativa</p>
              
              <div className="space-y-12 mb-16">
                <div className="flex flex-col items-center gap-8">
                  <div className="text-9xl font-black tracking-tighter text-white flex items-center gap-4">
                    {loanAmount} <span className="text-amber-500 text-5xl font-black">Ȼ</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="500" 
                    step="10" 
                    value={loanAmount} 
                    onChange={(e) => setLoanAmount(Number(e.target.value))} 
                    className="w-full h-4 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500 shadow-inner"
                  />
                  <p className="text-[11px] font-black text-slate-600 uppercase tracking-widest italic">Ajuste de Capital Solicitado</p>
                </div>

                <div className="bg-black/60 p-12 rounded-[4rem] text-left text-[13px] text-slate-400 space-y-8 border border-white/5 shadow-2xl">
                   <p className="flex gap-6 items-center font-bold uppercase tracking-tight leading-none"><span className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-500 flex items-center justify-center text-lg shrink-0 font-black">1</span> Abono inmediato de <b className="text-white ml-2">{loanAmount}Ȼ</b> al balance.</p>
                   <p className="flex gap-6 items-center font-bold uppercase tracking-tight leading-none"><span className="w-12 h-12 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-lg shrink-0 font-black">2</span> Condonación total al llegar a <b className="text-white ml-2">{currentStudent.balance < 1000 ? 1000 : 2000}Ȼ</b>.</p>
                   <p className="flex gap-6 items-center font-bold uppercase tracking-tight leading-none"><span className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-500 flex items-center justify-center text-lg shrink-0 font-black">3</span> Costo de mora: <b className="text-rose-400 ml-2">{loanAmount * 2}Ȼ</b> por incumplimiento.</p>
                </div>
              </div>

              <button 
                onClick={handleRequestLoan} 
                disabled={hasLoan} 
                className={`w-full font-black py-9 rounded-[3rem] text-[14px] uppercase tracking-[0.4em] shadow-2xl active:scale-95 transition-all ${hasLoan ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-white/5' : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/20'}`}
              >
                {hasLoan ? 'CALI-CRÉDITO ACTIVO' : 'CONTRATAR CALI-CRÉDITO'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showQRModal && (
        <div className="fixed inset-0 bg-slate-950/98 backdrop-blur-3xl z-[100] flex items-center justify-center p-6 animate-in zoom-in" onClick={() => setShowQRModal(false)}>
          <div className="bg-slate-900 rounded-[7rem] p-24 max-w-md w-full text-center border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="bg-white p-10 rounded-[4.5rem] inline-block mb-14 shadow-[0_0_100px_rgba(255,255,255,0.1)]"><QRGenerator value={currentStudent.id} size={280} /></div>
            <p className="text-white font-black text-5xl mb-10 uppercase tracking-tighter italic">{currentStudent.name}</p>
            <button onClick={() => setShowQRModal(false)} className="w-full bg-indigo-600 text-white font-black py-8 rounded-[3rem] text-[13px] uppercase tracking-widest shadow-2xl">Cerrar Pase</button>
          </div>
        </div>
      )}
    </div>
  );
};
