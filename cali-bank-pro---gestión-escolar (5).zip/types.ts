
export type TransactionType = 'CREDIT' | 'DEBIT';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  concept: string;
  timestamp: number;
}

export interface Loan {
  amount: number;
  timestamp: number;
  targetGoal: number;
  isActive: boolean;
}

export interface Group {
  id: string;
  name: string;
  createdAt: number;
}

export interface Reward {
  id: string;
  amount: number;
  isUsed: boolean;
  usedBy?: string;
  usedAt?: number;
  createdAt: number;
}

export interface Student {
  id: string;
  name: string;
  groupId: string;
  balance: number;
  transactions: Transaction[];
  qrCode: string;
  avatar: string;
  lastAttendance?: number;
  activeLoan?: Loan;
}

export enum UserMode {
  TEACHER = 'TEACHER',
  STUDENT = 'STUDENT',
  NONE = 'NONE'
}
